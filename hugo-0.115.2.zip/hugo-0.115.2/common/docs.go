// Package common provides common helper functionality for Hugo.
package common
