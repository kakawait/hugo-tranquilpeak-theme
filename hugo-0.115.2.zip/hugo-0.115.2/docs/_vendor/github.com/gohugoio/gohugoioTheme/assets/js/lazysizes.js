var lazysizes = require('lazysizes');
// var lsnoscript = require('lazysizes/plugins/noscript/ls.noscript.js');
var unveilhooks = require('lazysizes/plugins/unveilhooks/ls.unveilhooks.js');
