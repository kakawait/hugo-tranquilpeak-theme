---
title: Hugo Documentation
linktitle: Hugo
description: Hugo is the world's fastest static website engine. It's written in Go (aka Golang) and developed by bep, spf13 and friends.
menu:
  main:
    weight: 01
weight: 01
layout: documentation-home
---

Hugo is the **world's fastest static website engine.** It's written in Go (aka Golang) and developed by [bep](https://github.com/bep), [spf13](https://github.com/spf13) and [friends](https://github.com/gohugoio/hugo/graphs/contributors).

Below you will find some of the most common and helpful pages from our documentation.
