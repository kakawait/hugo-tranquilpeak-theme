---
title: About Hugo
linktitle: Overview
description: Hugo's features, roadmap, license, and motivation.
categories: []
keywords: []
menu:
  docs:
    parent: about
    weight: 1
weight: 1
aliases: [/about-hugo/,/docs/]
---

Hugo is not your average static site generator.
