---
title: echoParam
description: Prints a parameter if it is set.
categories: [functions]
menu:
  docs:
    parent: functions
keywords: []
signature: ["echoParam DICTIONARY KEY"]
relatedfuncs: []
---


```go-html-template
{{ echoParam .Params "project_url" }}
```
