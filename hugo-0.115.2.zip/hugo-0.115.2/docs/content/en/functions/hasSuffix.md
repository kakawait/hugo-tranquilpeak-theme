---
title: hassuffix
linktitle: hasSuffix
description: Tests whether a string ends with suffix.
date: 2023-03-01
publishdate: 2023-03-01
lastmod: 2023-03-01
categories: [functions]
menu:
docs:
parent: "functions"
keywords: [strings]
signature: ["hasSuffix STRING SUFFIX"]
workson: []
hugoversion:
relatedfuncs: [hasPrefix]
deprecated: false
aliases: []
---

* `{{ hasSuffix "Hugo" "go" }}` → true