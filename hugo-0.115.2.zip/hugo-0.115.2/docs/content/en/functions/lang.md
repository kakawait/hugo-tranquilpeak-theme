---
title: lang
package: lang
description: "TODO.."
categories: [functions]
keywords: [numbers]
menu:
  docs:
    parent: functions
signature: ["lang.NumFmt PRECISION NUMBER [OPTIONS [DELIMITER]]"]
aliases: ['/functions/numfmt/']
type: 'template-func'
---
